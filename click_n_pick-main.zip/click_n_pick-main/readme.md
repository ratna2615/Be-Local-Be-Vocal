### Click & Pick

Social Media App for Local Vendors

> Supporting Local Business

#### Download Links:

###### Android

[Universal](https://drive.google.com/file/d/1pKNOZzaEByIfwxXmtx8FfoJ1OTWz3N_A/view?usp=sharing)
